import sys, random

l = eval(sys.argv[1])

tl = [i for i in range(8, 17)]

# print("hello")
sys.stdout.flush()
print(str(random.choices([1, 2, 3, 4], k = 3)))

