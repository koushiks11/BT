// app.js
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const path = require('path')
// const {PythonShell} = require('python-shell')
// let options={
//   scriptPath:""
// }

// PythonShell.run("script.py",options,(err,res)=>{
//   if(err) console.log(err)
//   if(res) console.log(res)
// });
const spawn = require("child_process").spawn;
const pP=spawn('python',["F:\\demo\\python.py", [1, 2, 3, 4]])

pP.stdout.on('data',(data) => {
  console.log(data.toString())
});

// runPythonScript();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(bodyParser.json());

// app.get('/api/py', async (req, res) => {
//   try {
//     console.log("app");
//     const pythonOutput = await runPythonScript();
//     console.log('Python script output:', pythonOutput);

//     // Send the Python script output back to the front-end
//     res.json({ pythonOutput });
//   } catch (error) {
//     console.error('Failed to run Python script:', error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// Connect to MongoDB (Make sure you have MongoDB installed and running)
mongoose.connect('mongodb+srv://user1:user1@cluster0.1kvcm2i.mongodb.net/?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});
// Define User Schema
const userSchema = new mongoose.Schema({
  name: String,
  username: String,
  city: String,
  phone: String,
  password: String,
  role: String, // 'customer', 'agent'
});

// Define separate models for customers and agents
const Customer = mongoose.model('Customer', userSchema);
const Agent = mongoose.model('Agent', userSchema);

// Register Customer
app.post('/api/register/customer', async (req, res) => {
  try {
    const { name, username, city, phone, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newCustomer = new Customer({ name, username, city, phone, password: hashedPassword, role: 'customer' });
    await newCustomer.save();
    res.status(201).json({ message: 'Customer registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Register Agent
app.post('/api/register/agent', async (req, res) => {
  try {
    const { name, username, city, phone, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newAgent = new Agent({ name, username, city, phone, password: hashedPassword, role: 'agent' });
    await newAgent.save();
    res.status(201).json({ message: 'Agent registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Login User
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await Customer.findOne({ username, role: 'customer' }) || await Agent.findOne({ username, role: 'agent' });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ username: user.username, role: user.role }, 'secretkey');
    res.json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



// Middleware to verify JWT
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  jwt.verify(token, 'secretkey', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    req.user = user;
    next();
  });
};

// Example protected route
app.get('/api/profile', verifyToken, (req, res) => {
  res.json({ user: req.user });
});

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, "public1")));

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
