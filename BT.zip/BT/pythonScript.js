// // pythonScript.js
// const { PythonShell } = require('python-shell');
// const spawn = require('child_process').spawn;
// const scriptExecution = spawn("python.exe", ["script.py"]);

// const runPythonScript = () => {
//     // Handle normal output
//     scriptExecution.stdout.on('data', (data) => {
//         console.log(String.fromCharCode.apply(null, data));
//     });
    
//     // Write data (remember to send only strings or numbers, otherwhise python wont understand)
//     var data = JSON.stringify([1,2,3,4,5]);
//     scriptExecution.stdin.write(data);
//     // End data write
//     scriptExecution.stdin.end();
  
// };

// module.exports = runPythonScript;
