// script.js
function registerUser() {
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;
    const role = document.getElementById('regRole').value;
  
    axios.post('http://localhost:3001/api/register', { username, password, role })
      .then(response => {
        console.log(response.data.message);
      })
      .catch(error => {
        console.error(error.response.data.error);
      });
  }
  
  function loginUser() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
  
    axios.post('http://localhost:3001/api/login', { username, password })
      .then(response => {
        console.log('Login successful');
        const token = response.data.token;
        // Save the token in localStorage or a secure storage mechanism
        // For simplicity, we'll log it to the console
        console.log('Token:', token);
      })
      .catch(error => {
        console.error(error.response.data.error);
      });
  }
  
  function getUserProfile() {
    const token = prompt('Enter your token:'); // In a real app, you would securely retrieve the token
    if (!token) return;
  
    axios.get('http://localhost:3001/api/profile', {
      headers: { Authorization: token }
    })
      .then(response => {
        const userProfile = response.data.user;
        console.log('User Profile:', userProfile);
        document.getElementById('profileResult').textContent = `Username: ${userProfile.username}, Role: ${userProfile.role}`;
      })
      .catch(error => {
        console.error(error.response.data.error);
        document.getElementById('profileResult').textContent = 'Error fetching profile';
      });
  }
  